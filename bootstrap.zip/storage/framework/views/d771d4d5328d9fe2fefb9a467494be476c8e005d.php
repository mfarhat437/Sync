<?php $__env->startComponent('mail::message'); ?>
Welcome <?php echo e($data['data]->name); ?>


please copy this code and paste it in the next page
Code:: <?php echo e($token); ?>

<?php $__env->startComponent('mail::button', ['url' => <?php echo e(route('verify_code')); ?>]); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
