<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::middleware('auth:api')->get('/user', function (Request $request) {
   // return $request->user();
//});

Route::get('/test',function(){
    
    return response('helloooooooo');
});



//------------User Routes-----------//

Route::post('/register','usersController@register');
Route::post('/login','usersController@login');
Route::get('/edit_user','usersController@edit');
Route::put('/update_user/{id}','usersController@update');
Route::delete('/delete_user/{id}','usersController@destroy');

Route::post('/reset_password','usersController@reset_password');
Route::post('/verify_code','usersController@verify_code')->name('verify_code');
Route::post('/change_password','usersController@change_password');

Route::post('/register1','usersController@register_step1');
Route::post('/register2','usersController@register_step2');
Route::post('/register3','usersController@register_step3');


//------------FriendShips-----------//

Route::post('/send_friend_request','friendshipsController@send_friend_request');
Route::post('/accept_friend_request','friendshipsController@accept_friend_request');
Route::post('/deny_friend_request','friendshipsController@deny_friend_request');
Route::get('/list_friends_requests','friendshipsController@list_friends_requests');


Route::post('/find_friends','friendosController@search_friends');
route::get('/friends_list/{id}','friendosController@friend_list');


//------------Event Routes-----------//

Route::get('/events','eventscontroller@index');
Route::post('/create_event','eventscontroller@store');
Route::get('/edit_event/{id}','eventscontroller@edit');
Route::get('/show_event/{id}','eventscontroller@show');
Route::post('/update_event/{id}','eventscontroller@update');
Route::delete('/delete_event/{id}','eventscontroller@destroy');
Route::get('/event_categories','eventscontroller@categories');

//--------------Task Routes----------------//

Route::get('/event_tasks/{id}','taskscontroller@index');
Route::post('/create_task','taskscontroller@store');
Route::get('/edit_task/{id}','taskscontroller@edit');
Route::put('/update_task/{id}','taskscontroller@update');
Route::delete('/delete_task/{id}','taskscontroller@destroy');

//--------------Event Goings----------------//

Route::post('/going_to_event','goingsController@make_going');

//--------------Facebook Login----------------//

Route::get('/redirect', 'SocialAuthFacebookController@redirect');
Route::get('/callback', 'SocialAuthFacebookController@callback');


//--------------Invitations----------------//
Route::post('/send_invitation','invitationController@send_invitation');



//--------------Notifications----------------//
Route::get('/send_notification','eventscontroller@send_notification');




