
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">

		<title>Electro - HTML Ecommerce Template</title>

    </head>
	<body>
                    <form class="" method="POST" action="">
                        {{ csrf_field() }}
                        <input type="">

                              <a href="{{url('/redirect')}}" class="btn btn-primary">Login with Facebook</a>
                    </form>
    </body>
</html>