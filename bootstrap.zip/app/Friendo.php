<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Friendo extends Model
{
    protected $table='friendos';
    
public function users(){
    
    return $this->belongsToMany(User::class,'friend_user','friend_id','user_id');
    
}
}
