<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;
use App\Event;

class taskscontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        $event_tasks=Event::where('event_id',$id)->tasks->get();
        return response(['event_tasks'=> $event_tasks]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function choose_task(Request $request) 
    {
        $check=Task::where('id',$request->task_id)->pluck('status');
        
        if($check==0 ){
            
        
            Task::where('id',$request->task_id)->update([
                'user_id'=>$request->user_id,
                'status'=>1,
            ]);
            return response(['status'=>true,'message'=>'you have choosed the task successfully']);
        } else{
            
            return response(['status'=>false,'message'=>'sorry ..this task is already choosen by another one']);
        }   
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $task=new Task;
        $task->task_name=$request->task_name;
        if(auth()->check()){
            $task->user_id=auth()->user()->id;
        }else{
            $task->user_id=$request->user_id;
            
        }
        $task->event_id=$request->event_id;
        $task->status=$request->status;

        $task->save();
        return response(['status'=>true,'message'=>'task created successfully !']);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $task=Task::where('id',$id)->first();
        return response(['task'=> $task]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     $update_event=Task::where('id',$id)->update([
         
            'task_name'=>$request->task_name,
            'user_id'=>$request->user_id,
            'event_id'=>$request->event_id,
            'status'=>$request->status,
     ]) ;
        
        if($update_event)  {
            
            return response(['status'=>true,'message'=>'task updated successfully']);
        }  else{
            return response(['status'=>false,'message'=>'please try again !']);

            
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Task::find($id)->delete();
        return response(['status'=>true,'message'=>'task deleted successfully !']);
    }
}
