<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Validator;
use Illuminate\Support\Facades\Auth;
use Hash;
use App\Mail\reset_password;
use Carbon\Carbon;
use DB;
use Mail;
class usersController extends Controller
{
      
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
  //  public function __construct()
    //{
    //    $this->middleware('auth:api', ['except' => ['login']]);
   // }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login()
    {
        $credentials = request(['email', 'password']);

        
        if (! $token = auth()->attempt($credentials)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        $user_dettails=User::where('email',request('email'))->first();
        return $this->respondWithToken($token,$user_dettails);
    }
    
    
    
    public function me()
    {
        return response()->json(auth()->user());
    }
    
    
    protected function respondWithToken($token,$user_dettails)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth('api')->factory()->getTTL() * 60,
            'user_details'=>$user_dettails,
        ]);
    }

      
      //  if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
            
            
       // $user = $request->user();
            
       // $tokenResult = $user->createToken('Personal Access Token');
      //      
        //    return response(['status'=>true,'message'=>' you logged in successfully','access token'=>$tokenResult]);
       // }else{
       //     return response(['status'=>false,'message'=>' sorry Email or Password is not correct !']);
      //  }
       

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
       $validate=validator::make($request->all(),[
            
            'name'=>'required',
            'email'=>'required|email',
            'password'=>'required|min:8',
            'gender'=>'required',
            'password_confirm'=>'required',
            'phone'=>'required',

        ]);
       
    
        
        if($validate->fails()){
            return response(['status'=>false,'message'=>$validate->messages()]);
        }else{
            $data=new User;
            $data->name=$request->name;
            $data->email=$request->email;
            $data->phone=$request->phone;
            $data->gender=$request->gender;
            $data->image=$request->image;
            $data->password=Hash::make($request->password);
            $data->password_confirm=Hash::make($request->password_confirm);
            $data->save();
            return response(['status'=>true,'message'=>'you have registered successfully !']);

        }
    }
    
    
    
    
    public function register_step1(Request $request){
        
       $validate=validator::make($request->all(),[
            
            'name'=>'required',
            'email'=>'required|email',
            'gender'=>'required',
            'image'=>'required|image',
    ]);   
        
        if($validate->fails()){
            return response(['status'=>false,'message'=>$validate->messages()]);
        }else{
            $data=new User;
            $data->name=$request->name;
            $data->email=$request->email;
            $data->gender=$request->gender;
           
            $file=$request->file('image');
            $filename=time(). '.'.$file->getclientOriginalextension();
            $data->image=$filename;
            session()->put('user_email',$request->email);
            $data->save();

            return response(['status'=>true,'message'=>'register first step is successfully !']);
            
  

        }
           return $file->move(public_path('uploads/images'),$filename);

    }
    
    
    public function register_step2(Request $request){
        
       $validate=validator::make($request->all(),[
            
            'password'=>'required|min:8',
            'password_confirm'=>'required|min:8',
          
    ]);   
        
        if($validate->fails()){
            return response(['status'=>false,'message'=>$validate->messages()]);
        }else{
            $password=$request->passowrd;
            $password_confirm=$request->passowrd_confirm;
            
            if($password!==$password_confirm){
                
                return response(['error'=>'sorry the passowrd does not match']);
                
            }else{
                
            $email=session()->get('user_email');
            
            User::where('email',$email)->update([
                'password'=>Hash::make($request->password),
                'password_confirm'=>Hash::make($request->password_confirm),
                
            ]);
         
            return response(['status'=>true,'message'=>'register second step is successfully !']);
                }
        }
    }
    
    
    
    public function register_step3(Request $request){
        
       $validate=validator::make($request->all(),[
            
            'phone'=>'required',
           
          
    ]);   
        
        if($validate->fails()){
            return response(['status'=>false,'message'=>$validate->messages()]);
        }else{
           $email=session()->get('user_email');
            User::where('email',$email)->update([
                'phone'=>$request->phone,
                
            ]);
         
            return response(['status'=>true,'message'=>'register third step is successfully !']);
        }
    }
    
    
    
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=User::find($id)->first();
        return response(['user_data'=>$user]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
             $update_user=User::where('id',$id)->update([
         
            'name'=>$request->name,
            'email'=>$request->email,
            'phone'=>$request->phone,
            'image'=>$request->image,
            'gender'=>$request->gender,
            'password'=>bcrypt($request->password),
            'password_confirm'=>Hash::make($request->password_confirm),
                 
     ]) ;
        
        if($update_user)  {
            
            return response(['status'=>true,'message'=>'your data updated successfully']);
        }  else{
            return response(['status'=>false,'message'=>'please try again !']);

            
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       User::find($id)->delete();
        return response(['status'=>true,'message'=>'user deleted successfully !']);
    }
    
    public function reset_password(Request $request){
        
        $user=User::where('email',$request->email)->first();
        $token=str_random(50);
        if(!empty($user)){
            DB::table('password_resets')->insert([
                
                'email'=>$user->email,
                'token'=>$token,
                'created_at'=>Carbon::now(),
            ]);
            
            Mail::to($user->email)->send(new reset_password(['data'=>$user,'token'=>$token]));
            return response(['status'=>true,'message'=>'email sent successfully']); 
        }else{
            
            return response(['status'=>false,'message'=>'sorry incorrect email...try again']);
            
        }
    }
    
    
    public function verify_code(Request $request){
        
        
        $check=DB::table('password_resets')->where('token',$request->code)->first();
        
        if(!empty($check)){
        
            return response(['status'=>true,'message'=>'you reset password correctly']); 
        }else{
            
            return response(['status'=>false,'message'=>'sorry the code is incorrect']); 
            
        }
        
    }
    
    
    
    public function change_password(Request $request){
        
        $new_pass=$request->new_password;
        $new_confirm=$request->password_confirm;
        if($new_pass==$new_confirm){
            
            User::where('id',auth()->user()->id)->update([
                'password'=>Hash::make($new_pass),
                'password_confirm'=>Hash::make($new_confirm),
                
            ]);
            
            return response(['status'=>true,'message'=>' password updated successfully']); 
        
    }else{
        
            return response(['status'=>false,'message'=>' the password does not match']); 
    }
    
    
    
}
    
}
