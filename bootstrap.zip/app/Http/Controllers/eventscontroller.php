<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Event;
use Validator;
use App\User;
use App\Category_event;
use App\Notifications\SomeoneCreatedEvent;
use Notification;
class eventscontroller extends Controller
{
    
    
   private $notify;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $all_events=Event::orderby('id','desc')->get();
        return response(['stauts'=>true,'events'=>$all_events]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function categories()
    {
        $event_categories=Category_event::all();
        return response(['categories'=>$event_categories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
             $validate=validator::make($request->all(),[
            
            'name'=>'required',
            'place'=>'required',
            'description'=>'required',
            'event_date'=>'required',
            'event_time'=>'required',
            'min_number'=>'min:1',

        ]
       
    );
        
        if($validate->fails()){
            return response(['status'=>false,'message'=>$validate->messages()]);
        }else{
            $data=new Event ;
            $data->name=$request->name;
            $data->place=$request->place;
            $data->description=$request->description;
            $data->event_date=$request->event_date;
            $data->event_time=$request->event_time;
            $data->min_number=$request->min_number;
            $data->max_number=$request->max_number;
            $data->cost=$request->cost;
            
           if(auth()->check()){
               $data->user_id=auth()->user()->id;
           } else{
               $user_id=$request->user_id;
               $data->user_id=$user_id;

               $event_creater=User::select('name')->where('id', $user_id)->pluck('name');
               session()->put('event_creater',$event_creater);
   
           }
            $event_creater=session()->get('event_creater');
            session()->push('event',[
                'event_name'=>$request->name,
                'event_creater'=>$event_creater,
                'event_date'=>$request->event_date,
                'event_time'=>$request->event_time,
            
            ]);
            $data->save();
            
            //session()->put('event_id',Event::where('name',$request->name)->id);
            return response(['status'=>true,'message'=>'Event created successfully !']);
           // Notification::send($notify_users,newSomeoneCreatedEvent($data));
        }
    }
    
    
  public function send_notification(){
        $sender=session()->get('event_creater');
        $friends=$sender->getAllFriendships();

          //  Notification::send(User::find(1),new SomeoneCreatedEvent());
            OneSignal::sendNotificationToUser([
                'eventt_creater'=>sonession()->get('event')[1]['event_creater'],
                'event_name'=>session()->get('event')[0]['event_name'],
                'event_date'=>session()->get('event')[2]['event_date'],
                'event_time'=>session()->get('event')[3]['event_date'],
                ],
                
                1,
                $url = null,
                $data = null,
                $buttons = null,
                $schedule = null
            );
      
        
            return response(['status'=>true,'message'=>'notification sent successfully']);
        
  }

    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $event=Event::where('id',$id)->first();
        $count=Event::where('id',$id)->withCount('goings')->pluck('goings_count'); 
        return response(['event'=>$event,'going'=>$count]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $event=Event::where('id',$id)->first();
        return response(['event'=>$event]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    Event::where('id',$id)->update([
         
            'name'=>$request->name,
            'place'=>$request->place,
            'description'=>$request->description,
            'event_date'=>$request->event_date,
            'event_time'=>$request->event_time,
            'min_number'=>$request->min_number,
            'max_number'=>$request->max_number,
            'cost'=>$request->cost,    
     ]) ;
        
            
            return response(['status'=>true,'message'=>'event data updated successfully']);
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Event::find($id)->delete();
        return response(['status'=>true,'message'=>'event deleted successfully !']);
    }
}
