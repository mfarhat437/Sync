<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class friendshipsController extends Controller
{

    public function send_friend_request(Request $request){
        
        $user=User::where('id',$request->sender_id)->first();  
        $recipient=User::where('id',$request->recipient_id)->first();
        session()->put('sender',$user);
        session()->put('recipient',$recipient); 
        $user->befriend($recipient);
        if($user->hasSentFriendRequestTo($recipient)){
        
        return response(['status'=>true,'message'=>'friend request sent successfully']);
        }else{
        return response(['status'=>false]);     
        }

    }
    
    
    public function accept_friend_request(){
        
        $user=session()->get('recipient');
        $sender=session()->get('sender');
        if($sender->hasSentFriendRequestTo($user)) {
       $user->acceptFriendRequest($sender);
}       

        if($user->isFriendWith($sender)){
        
        return response(['status'=>true,'message'=>'congrats you are now friends!']);
        
        }else{
        return response(['status'=>false,'message'=>'you are not friends!']);
        }

    }
    
    public function deny_friend_request(){
        
        $user=session()->get('recipient');
        $sender=session()->get('sender');
        
        $user->denyFriendRequest($sender);
            
        return response(['status'=>true,'message'=>'friendship denied successfully!']);

    }
    
    
    public function list_friends_requests(){
        
        $user=session()->get('recipient');
        $list=$user->getFriendRequests();

        if(!empty($list)){
            
        return response(['status'=>true,'list'=>$list]);
        }else{
            
        return response(['status'=>false,'list'=>'there is no friends requests for you']);

        }
    }


}
