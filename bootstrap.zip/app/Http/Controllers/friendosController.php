<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Friendo;

class friendosController extends Controller
{
    public function search_friends(Request $request){
        
        $user_id=$request->user_id;
        $data=array("11111111","1094373485","0187962222","01248794444");
        $count=count($data);
        
        
        for($i=0; $i<$count;){
            $mob=$data[$i];
            $search=User::where('phone',$mob)->first();
            $name=$search['name'];
            $phone=$search['phone'];
            if(!empty($search)){
                $add_friend= new Friendo;
                $add_friend->name= $name;
                $add_friend->phone=$phone;
                $user=User::findOrFail($user_id);
                $add_friend->save();
                $friend_id=$add_friend['id'];
                $user->friendos()->attach($friend_id);
                $i++;
                return response(['status'=>true,'message'=>$search]);
            }else{
                
                return response(['status'=>false,'message'=>'sorry you have no friends in the app']);
            }
            

        }
        
        
    
    }
    
    
    public function friend_list($id){
       
        $user=User::find($id);
        $friends=$user->friendos()->get();
        return response(['friends_list'=>$friends]);
    }
}
