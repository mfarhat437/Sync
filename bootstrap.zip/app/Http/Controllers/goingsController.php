<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Going;
use App\Event;
use Illuminate\Support\Facades\DB;
class goingsController extends Controller
{
    
    
    
    public function make_going (Request $request){
        $event_id=$request->event_id;
       
        
        $event_max_num=Event::where('id',$event_id)->select('max_number');
       // count goings to this event...
        $count=Event::where('id',$event_id)->select('going_count'); 
       // $count=$count->goings->count();
        if($event_max_num<=$count){
            
        return response(['status'=>false,'message'=>'sorry..there is no place in this event']);
        }
            $user_id=$request->user_id ;
            $event_id=$request->event_id ;
            $check=Going::where('user_id', $user_id)->where('event_id', $event_id)->firstorfail();
            if($check!=null){
                return response(['status'=>false,'message'=>'you are aleardy in !' ]);
            }
                
        $going_data=new Going();
        $going_data->event_id=$request->event_id;
        $going_data->user_id=$request->user_id ;
        DB::table('events')->where('id',$request->event_id)->update(['going_count'=>DB::raw('going_count+1')]);    

        $going_data->save();
        return response(['status'=>true,'message'=>'you have joined this activity successfully']);
            
            
        
    }
}
