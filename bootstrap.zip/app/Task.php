<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $table='tasks';
    
    public function event (){
        
        return $this->belongTo('App\Event');
    }
    
    
    public function user (){
        
        return $this->belongTo('App\User');
    }
    
}
